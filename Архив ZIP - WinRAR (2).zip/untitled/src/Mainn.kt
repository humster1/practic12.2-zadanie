import kotlinx.coroutines.delay
import java.net.URL

fun main() {
    println("Введите имя пользователя:")
    val username = readLine()
    println("Введите токен GitHub:")
    val token = readLine()


    val isBlocking = true

    if (isBlocking) {
        println("Загрузка участника...")


        Thread.sleep(5000)


        val url = "https://api.github.com/repos/{username}/{repo}/contributors"
            .replace("{username}", username!!)
            .replace("{repo}", "example-repo")
        val data = URL(url).readText()


        val contributors = parseData(data)
        contributors.sortedByDescending { it.numRepositories }.forEach {
            println("${it.username} (${it.numRepositories} репозиториев)")
        }
    }
}

data class Contributor(val username: String, val numRepositories: Int)

fun parseData(data: String): List<Contributor> {

    val contributors = mutableListOf<Contributor>()

    return contributors
}